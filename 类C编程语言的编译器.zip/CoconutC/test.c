#include "for_gcc_build.hh"

int main() 
{
    int a;
    a=1;
    
   switch(a)
   {
    case 1:
      a=1;
    case 2:
      a=2;
    case 3:
       switch(a)
   {
    case 1:
      a=1;
    case 2:
      a=2;
    case 3:
      a=2;
   }
   }
   return 0;
}