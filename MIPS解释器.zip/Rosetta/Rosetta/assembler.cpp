#include "assembler.h"

int assembler::fromIns(string& str)	//��ָ�����м���룬�м�����ֵ�����˲�����������������
{
	int code = 0;
	for (int index = 0; index < 1; index++, code++)
		if (str == ins_reg1Imm0[index])return code;
	for (int index = 0; index < 2; index++, code++)
		if (str == ins_reg0Imm1[index])return code;
	for (int index = 0; index < 3; index++, code++)
		if (str == ins_reg1Imm1[index])return code;
	for (int index = 0; index < 12; index++, code++)
		if (str == ins_reg2Imm1[index])return code;
	for (int index = 0; index < 13; index++, code++)
		if (str == ins_reg3Imm0[index])return code;
}

int assembler::fromReg(string& str)
{
	if (str == "$0" || str == "$zero")return 0;
	else if (str == "$1" || str == "$at")return 1;
	else if (str == "$2" || str == "$v0")return 2;
	else if (str == "$3" || str == "$v1")return 3;
	else if (str == "$4" || str == "$a0")return 4;
	else if (str == "$5" || str == "$a1")return 5;
	else if (str == "$6" || str == "$a2")return 6;
	else if (str == "$7" || str == "$a3")return 7;
	else if (str == "$8" || str == "$t0")return 8;
	else if (str == "$9" || str == "$t1")return 9;
	else if (str == "$10" || str == "$t2")return 10;
	else if (str == "$11" || str == "$t3")return 11;
	else if (str == "$12" || str == "$t4")return 12;
	else if (str == "$13" || str == "$t5")return 13;
	else if (str == "$14" || str == "$t6")return 14;
	else if (str == "$15" || str == "$t7")return 15;
	else if (str == "$16" || str == "$s0")return 16;
	else if (str == "$17" || str == "$s1")return 17;
	else if (str == "$18" || str == "$s2")return 18;
	else if (str == "$19" || str == "$s3")return 19;
	else if (str == "$20" || str == "$s4")return 20;
	else if (str == "$21" || str == "$s5")return 21;
	else if (str == "$22" || str == "$s6")return 22;
	else if (str == "$23" || str == "$s7")return 23;
	else if (str == "$24" || str == "$t8")return 24;
	else if (str == "$25" || str == "$t9")return 25;
	else if (str == "$26" || str == "$k0")return 26;
	else if (str == "$27" || str == "$k1")return 27;
	else if (str == "$28" || str == "$gp")return 28;
	else if (str == "$29" || str == "$sp")return 29;
	else if (str == "$30" || str == "$s8" || str == "$fp")return 30;
	else if (str == "$31" || str == "$ra")return 31;

	return 0;
}

void assembler::fromImm(string& str, instructTy& ins)
{
	if (isNum(str))
		ins.second.push_back(stoi(str));
	else
		fromNumAndReg(str, ins);
}

int assembler::fromNumAndReg(string& str, instructTy& ins)
{
	static string num, reg;

	//��ָ������ȡ�Ĵ���
	auto pos = str.find('(') + 1;
	reg = str.substr(pos);
	reg.pop_back();

	//��ָ������ȡ����
	num = string(str.begin(), str.begin() + pos - 1);

	ins.second.push_back(stoi(num));
	ins.second.push_back(fromReg(reg));

	return 0;
}

void assembler::toObjCode(vector<vector<string>>& srcInstruct)
{
	instructTy ins;
	for (auto& iter : srcInstruct)
	{
		ins.first = fromIns(iter[0]);

		switch (ins.first)			//����ָ�����������Ҫ��ν���������
		{
		case 0:
			ins.second.push_back(fromReg(iter[1])); break;
		case 1:	case 2:
			fromImm(iter[1], ins);
			break;
		case 3:	case 4: case 5:
			ins.second.push_back(fromReg(iter[1]));
			fromImm(iter[2], ins);
			break;
		case 6:	case 7: case 8: case 9:	case 10: case 12: case 13: case 14: case 15: case 16: case 17:
			ins.second.push_back(fromReg(iter[1]));
			ins.second.push_back(fromReg(iter[2]));
			fromImm(iter[3], ins);
			break;
		default:
			ins.second.push_back(fromReg(iter[1]));
			ins.second.push_back(fromReg(iter[2]));
			ins.second.push_back(fromReg(iter[3])); break;
		}

		objInstruct.push_back(move(ins));
	}
}

vector<instructTy> assembler::getObjCode()
{
	return objInstruct;
}
