#pragma once

/*
����˼Ĵ����Ķ���
*/

extern long registers[32];
typedef long& registerAlias;

registerAlias zero = registers[0], at = registers[1], v0 = registers[2], v1 = registers[3], a0 = registers[4], a1 = registers[5],
a2 = registers[6], a3 = registers[7], t0 = registers[8], t1 = registers[9], t2 = registers[10], t3 = registers[11], t4 = registers[12],
t5 = registers[13], t6 = registers[14], t7 = registers[15], s0 = registers[16], s1 = registers[17], s2 = registers[18], s3 = registers[19],
s4 = registers[20], s5 = registers[21], s6 = registers[22], s7 = registers[23], t8 = registers[24], t9 = registers[25], k0 = registers[26],
k1 = registers[27], gp = registers[28], sp = registers[29], s8 = registers[30], fp = registers[30], ra = registers[31];