#include "preprocessor.h"

//��źͼĴ���/�������������Ӧ��ָ����ɵ���˳��
string ins_reg1Imm0[]{ "jr" };
string ins_reg0Imm1[]{ "j","jal" };
string ins_reg1Imm1[]{ "lui","lw","sw" };
string ins_reg2Imm1[]{ "sll","srl","sra","addi","addiu","andi","ori","xori","beq","bne","slti","sltiu" };
string ins_reg3Imm0[]{ "add","addu","sub","subu","and","or","xor","nor","slt","sltu","sllv","srlv","srav" };

//�Ĵ�������
string regName[]{
"$k0","$k1","$t8","$t9","$v0","$v1","$zero","$at","$gp","$sp","$s8","$fp","$ra","$t0","$t1","$t2","$t3",
"$a0","$a1","$a2","$a3","$a4","$a5","$a6","$a7","$s0","$s1","$s2","$s3","$s4","$s5","$s6","$s7","$0","$1",
"$2","$3","$4","$5","$6","$7","$8","$9","$10","$11","$12","$13","$14","$15","$16","$17","$18","$19","$20",
"$21","$22","$23","$24","$25","$26","$27","$28","$29","$30","$31", };

void trim(string& s)		//ɾ���ַ��������пո�
{
	int index = 0;
	while ((index = s.find(' ', index)) != string::npos)
		s.erase(index, 1);
}

bool isReg(string& reg)
{
	for (auto& iter : regName)
		if (reg == iter)return true;
	return false;
}

//�п��ܵ��������֣�Ҳ�п���������+�Ĵ���
bool isImm(string& imm)
{
	return isNum(imm) || isNumAndReg(imm);
}

bool isNum(string& num)
{
	for (auto& iter : num)
		if (iter < '0' || iter>'9')return false;
	return true;
}

bool isNumAndReg(string& str)
{
	std::regex reg("\\d*[(].+[)]");						//�ж��Ƿ����100($0)�ĸ�ʽ
	bool isMatch = std::regex_match(str, reg);

	if (isMatch)
	{
		auto pos = str.find('(') + 1;	//��ָ������ȡ�Ĵ���
		static string tmp = str.substr(pos);
		tmp.pop_back();

		if (isReg(tmp))return true;
		else return false;
	}
	else
		return false;
}

void preprocessor::split(vector<string> ins)
{
	auto pos = string::iterator();
	for (auto& iter : ins)
	{
		pos = find(iter.begin(), iter.end(), ' ');
		if (pos != iter.end())
			*pos = ',';																		//�滻��һ���ո�Ϊ����
		trim(iter);																		//ɾ�����пո�

		for (auto& ch : iter)
			if (ch >= 'A' && ch <= 'Z')
				ch = tolower(ch);
	}

	string item;
	instructs.resize(ins.size());
	for (int index = 0, size = ins.size(); index < size; index++)
	{
		istringstream stream(ins[index]);
		for (; getline(stream, item, ',');)
		{
			if (item.length() == 0)continue;		//Ϊ�գ��Թ�
			instructs[index].push_back(item);
		}
	}
}

vector<vector<string>> preprocessor::getResult()
{
	return instructs;
}

bool preprocessor::grammerChecker(vector<string>& ins)
{
	split(ins);

	bool errOccur = false;			//��ʾ������������
	errType opStatus = noErr;			//��ʾ��������������
	decltype(&preprocessor::reg0Imm1) checker;

	for (int size = instructs.size(), index = 0; index < size; index++)
	{
		checker = isInstruct(instructs[index][0]);

		if (checker == nullptr)
		{
			reportGrammerError(index + 1, errType::noIns);
			errOccur = true;
		}
		else
		{
			opStatus = checker(instructs[index]);
			if (opStatus != noErr)
				errOccur = true, reportGrammerError(index + 1, opStatus);
		}
	}

	if (errOccur)	return false;
	else            return true;
}

void preprocessor::reportGrammerError(int posLine, errType err)
{
	switch (err)
	{
	case preprocessor::noIns:
		printf("�� %d �г����˴��󣺲����ڸ�ָ��\n", posLine); break;
	case preprocessor::errReg:
		printf("�� %d �г����˴��󣺲����ڵļĴ�������\n", posLine); break;
	case preprocessor::errImm:
		printf("�� %d �г����˴��󣺲��Ϸ���������\n", posLine); break;
	case preprocessor::errArgv:
		printf("�� %d �г����˴��󣺲�����������߹���\n", posLine); break;
	}
}

preprocessor::errType preprocessor::reg3Imm0(vector<string>& argvs)
{
	if (argvs.size() != 4)
		return errArgv;
	else if (!isReg(argvs[1]) || !isReg(argvs[2]) || !isReg(argvs[3]))
		return errReg;
	else
		return noErr;
}

preprocessor::errType preprocessor::reg1Imm0(vector<string>& argvs)
{
	if (argvs.size() != 2)
		return errArgv;
	else if (!isReg(argvs[1]))
		return errReg;
	else
		return noErr;
}

preprocessor::errType preprocessor::reg2Imm1(vector<string>& argvs)
{
	if (argvs.size() != 4)
		return errArgv;
	else if (!isReg(argvs[1]) || !isReg(argvs[2]))
		return errReg;
	else if (!isImm(argvs[3]))
		return errImm;
	else
		return noErr;
}

preprocessor::errType preprocessor::reg1Imm1(vector<string>& argvs)
{
	if (argvs.size() != 3)
		return errArgv;
	else if (!isReg(argvs[1]))
		return errReg;
	else if (!isImm(argvs[2]))
		return errImm;
	else
		return noErr;
}

preprocessor::errType preprocessor::reg0Imm1(vector<string>& argvs)
{
	if (argvs.size() != 2)
		return errArgv;
	else if (!isImm(argvs[1]))
		return errImm;
	else
		return noErr;
}

decltype(&preprocessor::reg0Imm1) preprocessor::isInstruct(string& ins)
{
	for (auto& iter : ins_reg1Imm0)
		if (ins == iter)return reg1Imm0;
	for (auto& iter : ins_reg0Imm1)
		if (ins == iter)return reg0Imm1;
	for (auto& iter : ins_reg1Imm1)
		if (ins == iter)return reg1Imm1;
	for (auto& iter : ins_reg2Imm1)
		if (ins == iter)return reg2Imm1;
	for (auto& iter : ins_reg3Imm0)
		if (ins == iter)return reg3Imm0;

	return nullptr;
}
