#pragma once
#include "assembler.h"

/*
ִ�о�����������Ļ�����
*/

extern int appStack[1024];		//����ջ
extern long int registers[32];	//�Ĵ���

class exec
{
private:
	void jr(vector<int>& args);
	void j(vector<int>& args);
	void jal(vector<int>& args);
	void lui(vector<int>& args);
	void lw(vector<int>& args);
	void sw(vector<int>& args);
	void sll(vector<int>& args);
	void srl(vector<int>& args);
	void sra(vector<int>& args);
	void addi(vector<int>& args);
	void addiu(vector<int>& args);
	void andi(vector<int>& args);
	void ori(vector<int>& args);
	void xori(vector<int>& args);
	void beq(vector<int>& args);
	void bne(vector<int>& args);
	void slti(vector<int>& args);
	void sltiu(vector<int>& args);
	void add(vector<int>& args);
	void addu(vector<int>& args);
	void sub(vector<int>& args);
	void subu(vector<int>& args);
	void and_(vector<int>& args);
	void or_(vector<int>& args);
	void xor_(vector<int>& args);
	void nor_(vector<int>& args);
	void slt(vector<int>& args);
	void sltu(vector<int>& args);
	void sllv(vector<int>& args);
	void srlv(vector<int>& args);
	void srav(vector<int>& args);

private:
	int pc = 0;
	vector<instructTy> code;

public:
	exec() {}
	void execCode(vector<instructTy>& code_);
};