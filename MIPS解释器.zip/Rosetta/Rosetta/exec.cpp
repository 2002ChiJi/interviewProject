#include "exec.h"


int appStack[1024]{};
long int registers[32]{};

void exec::execCode(vector<instructTy>& code_)
{
	code = code_;
	for (size_t size = code.size(); pc < size;)
	{
		switch (code[pc].first)
		{
		case 0: jr(code[pc].second); pc--; break;
		case 1: j(code[pc].second); pc--; break;
		case 2: jal(code[pc].second); pc--; break;
		case 3: lui(code[pc].second); break;
		case 4: lw(code[pc].second); break;
		case 5: sw(code[pc].second); break;
		case 6: sll(code[pc].second); break;
		case 7: srl(code[pc].second); break;
		case 8: sra(code[pc].second); break;
		case 9: addi(code[pc].second); break;
		case 10: addiu(code[pc].second); break;
		case 11: andi(code[pc].second); break;
		case 12: ori(code[pc].second); break;
		case 13: xori(code[pc].second); break;
		case 14: beq(code[pc].second); break;
		case 15: bne(code[pc].second); break;
		case 16: slti(code[pc].second); break;
		case 17: sltiu (code[pc].second); break;
		case 18: add(code[pc].second); break;
		case 19: addu(code[pc].second); break;
		case 20: sub(code[pc].second); break;
		case 21: subu(code[pc].second); break;
		case 22: and_(code[pc].second); break;
		case 23: or_(code[pc].second); break;
		case 24: xor_(code[pc].second); break;
		case 25: nor_(code[pc].second); break;
		case 26: slt(code[pc].second); break;
		case 27: sltu(code[pc].second); break;
		case 28: sllv(code[pc].second); break;
		case 29: srlv(code[pc].second); break;
		case 30: srav(code[pc].second); break;
		}
		registers[0] = 0, pc++;
	}
}

void exec::jr(vector<int>& args)
{
	pc = registers[args[0]];
}

void exec::j(vector<int>& args)
{
	pc += args[0];
}

void exec::jal(vector<int>& args)
{
	registers[31] = pc + 4;
	pc += args[0];
}

void exec::lui(vector<int>& args)
{
	registers[args[0]] = args[1] << 16;
}

void exec::lw(vector<int>& args)
{
	registers[args[0]] = appStack[registers[args[1]] + args[2]];
}

void exec::sw(vector<int>& args)
{
	appStack[args[1] + registers[args[2]]] = registers[args[0]];
}

void exec::sll(vector<int>& args)
{
	registers[args[0]] = registers[args[1]] << args[2];
}

void exec::srl(vector<int>& args)
{
	registers[args[0]] = static_cast<long unsigned>(registers[args[1]]) >> args[2];
}

void exec::sra(vector<int>& args)
{
	registers[args[0]] = registers[args[1]] >> args[2];
}

void exec::addi(vector<int>& args)
{
	registers[args[0]] = registers[args[1]] + args[2];
}

void exec::addiu(vector<int>& args)
{
	registers[args[0]] = static_cast<unsigned long>(registers[args[1]]) + static_cast<unsigned long>(args[2]);
}

void exec::andi(vector<int>& args)
{
	registers[args[0]] = registers[args[1]] & args[2];
}

void exec::ori(vector<int>& args)
{
	registers[args[0]] = registers[args[1]] | args[2];
}

void exec::xori(vector<int>& args)
{
	registers[args[0]] = registers[args[1]] ^ args[2];
}

void exec::beq(vector<int>& args)
{
	pc = (registers[args[0]] == registers[args[1]] ? pc + 4 + args[2] : pc);
}

void exec::bne(vector<int>& args)
{
	pc = (registers[args[0]] != registers[args[1]] ? pc + 4 + args[2] : pc);
}

void exec::slti(vector<int>& args)
{
	registers[args[0]] = (registers[args[1]] < args[2] ? 1 : 0);
}

void exec::sltiu(vector<int>& args)
{
	registers[args[0]] = (static_cast<unsigned long>(registers[args[1]]) < static_cast<unsigned long>(args[2]) ? 1 : 0);
}

void exec::add(vector<int>& args)
{
	registers[args[0]] = registers[args[1]] + registers[args[2]];
}

void exec::addu(vector<int>& args)
{
	registers[args[0]] = static_cast<unsigned long>(registers[args[1]]) + static_cast<unsigned long>(registers[args[2]]);
}

void exec::sub(vector<int>& args)
{
	registers[args[0]] = registers[args[1]] - registers[args[2]];
}

void exec::subu(vector<int>& args)
{
	registers[args[0]] = static_cast<unsigned long>(registers[args[1]]) - static_cast<unsigned long>(registers[args[2]]);
}

void exec::and_(vector<int>& args)
{
	registers[args[0]] = registers[args[1]] & registers[args[2]];
}

void exec::or_(vector<int>& args)
{
	registers[args[0]] = registers[args[1]] | registers[args[2]];
}

void exec::xor_(vector<int>& args)
{
	registers[args[0]] = registers[args[1]] ^ registers[args[2]];
}

void exec::nor_(vector<int>& args)
{
	registers[args[0]] = ~(registers[args[1]] | registers[args[2]]);
}

void exec::slt(vector<int>& args)
{
	registers[args[0]] = (registers[args[1]] < registers[args[2]] ? 1 : 0);
}

void exec::sltu(vector<int>& args)
{
	registers[args[0]] = (static_cast<unsigned long>(registers[args[1]]) < static_cast<unsigned long>(registers[args[2]]) ? 1 : 0);
}

void exec::sllv(vector<int>& args)
{
	registers[args[0]] = registers[args[1]] << registers[args[2]];
}

void exec::srlv(vector<int>& args)
{
	registers[args[0]] = static_cast<long unsigned>(registers[args[1]]) >> registers[args[2]];
}

void exec::srav(vector<int>& args)
{
	registers[args[0]] = registers[args[1]] >> registers[args[2]];
}
